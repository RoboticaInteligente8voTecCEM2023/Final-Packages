Tu test this code, you need to download the hector quadrotor github at https://github.com/aaceves/hector_quadrotor, after it it is necesary to add the 
drone_controll ros pkg to your workspace src, then run catkin_make 
